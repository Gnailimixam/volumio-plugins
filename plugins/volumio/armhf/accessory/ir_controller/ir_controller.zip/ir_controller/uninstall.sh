#!/bin/bash

echo "Removing dependencies"
sudo apt-get -y purge --auto-remove lirc

echo "Done"
echo "pluginuninstallend"
